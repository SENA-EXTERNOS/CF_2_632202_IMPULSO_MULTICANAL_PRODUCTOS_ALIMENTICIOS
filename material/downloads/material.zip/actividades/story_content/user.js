function ExecuteScript(strId)
{
  switch (strId)
  {
      case "695qn7dLGpD":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

