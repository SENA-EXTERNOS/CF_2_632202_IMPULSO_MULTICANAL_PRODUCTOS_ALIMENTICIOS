function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5oXjC2lEiVr":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

